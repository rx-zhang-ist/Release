package cn.ist.management.vo.modelsimilarity;

import lombok.Data;

@Data
public class InsertModelResponse {
    private int code;
    private String message;
}

package cn.ist.management.vo.fromFront;public class QueryDataSourceFromVO {
}

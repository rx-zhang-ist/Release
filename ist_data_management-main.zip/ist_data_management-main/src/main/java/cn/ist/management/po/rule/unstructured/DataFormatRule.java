package cn.ist.management.po.rule.unstructured;

import java.util.List;
import java.util.Map;

//设定图像格式如JPG、PNG等
public class DataFormatRule extends UnstructuredRule{

    @Override
    public void filter(List<Map<String, Object>> rows) {

    }
}

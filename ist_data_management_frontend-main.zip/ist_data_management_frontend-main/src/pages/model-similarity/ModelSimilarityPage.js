import React, {useEffect, useState} from 'react'
import {Button, Divider, Empty, Form, message, Pagination, Select, Tag} from 'antd'
import DataModelCard from '../data-model/components/DataModelCard'
import {getDataModels, querySimilarModels} from '../../apis/data-model'

const {Option} = Select

const ModelSimilarityPage = () => {
    const pageSize = 6
    const [modelsToSearch, setModelsToSearch] = useState([])
    const [dataModels, setDataModels] = useState([])
    const [currentPage, setCurrentPage] = useState(1)
    const currentDataModels = dataModels.slice((currentPage - 1) * pageSize, currentPage * pageSize)
    const [searchForm] = Form.useForm()

    const handlePageChange = (page) => {
        setCurrentPage(page)
    }

    const fetchModels = () => {
        getDataModels().then(data => {
            setModelsToSearch(data)
        }).catch(error => {
            message.error(`获得模型失败：${error.message}`)
        })
    }

    const filterDataModel = (input, option) => {
        const model = modelsToSearch.find(item => item.id === option.value)
        return model.modelName.toLowerCase().includes(input.toLowerCase())
    }

    const searchSimilarModel = (data) => {
        const modelToSearch = modelsToSearch.find(item => item.id === data?.dataSourceId)
        if (modelToSearch) {
            const fields = modelToSearch.fields?.map(item => !['_source_id_', '__id__'].includes(item.name) && item.name).filter(i => i)
            const loading = message.loading('相似查询中...', 0)
            querySimilarModels({fields}).then(data => {
                const filteredData = data.filter(item => item.id !== modelToSearch.id)
                setCurrentPage(1)
                setDataModels(filteredData)
                loading()
            }).catch(error => {
                loading()
                message.error(`查询相似模型失败：${error.message}`)
            })
        } else {
            message.error('无待查询的数据模型')
        }
    }

    useEffect(fetchModels, [])

    return (
        <>
            <Form form={searchForm} layout='inline' onFinish={searchSimilarModel} className='inline-form'>
                <Form.Item label='数据模型' name='dataSourceId' style={{minWidth: 400}}>
                    <Select showSearch placeholder='请选择数据模型' filterOption={filterDataModel}>
                        {modelsToSearch.map(item => (
                            <Option key={item.id} value={item.id}>
                                <span style={{marginRight: '16px'}}>{item.modelName}</span>
                                <Tag>{item.id}</Tag>
                            </Option>
                        ))}
                    </Select>
                </Form.Item>
                <Button type='primary' htmlType='submit'>相似查询</Button>
            </Form>
            <Divider style={{margin: '12px 0'}}/>
            {currentDataModels.length > 0 ? (
                <div style={{display: 'flex', flexWrap: 'wrap'}}>
                    {currentDataModels.map((model, idx) => (
                        <DataModelCard key={idx} model={model} showOperation={false}/>
                    ))}
                </div>
            ) : <Empty/>}
            <div style={{display: 'flex', justifyContent: 'center', marginTop: '20px'}}>
                <Pagination
                    current={currentPage}
                    onChange={handlePageChange}
                    total={dataModels.length}
                    pageSize={pageSize}
                />
            </div>
        </>
    )
}

export default ModelSimilarityPage
